<?php 
    include("db.php");


?>


<?php  include("includes/header.php") ?>
<nav class ="navbar navbar-dark bg-dark">        
        <a href="dashboard.html" class="caja_nav" style="background-color: blue; color: aliceblue;">Inicio</a>
        <a href="#" class="caja_nav">Empleados</a>
        <a href="productos.html" class="caja_nav">Productos</a>
        <a href="proveedores.html" class="caja_nav">proveedores</a>
    </nav>

    <h1>Hello World</h1>

<div class="container-p4">
    <div class="row">
        <div class="col-md-4">

            <div class="card card-body">
                <form action="save.php">
                    <div class="form-group">
                        <input type="text" name="title" class="form-control"
                        placeholder="taskHere">
                    </div>
                    <div class="form-group">
                        <input name="description" rows="2" class="form-control"
                        placeholder="Task Description">                    </div>
                    <input type="submit" class="btn btn-success btn-block"
                    name="save_task" value="Save Task">

                    
                </form>
            
            </div>

        </div>
        <div class="col-md-8">
            
        </div>
    </div>

</div>


    <?php  include("includes/footer.php") ?>